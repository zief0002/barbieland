
library(tidyverse)
#Simulate for instructor with mean 80 and large standard deviation
grade1 <- data.frame(c(rnorm(50, mean = 80, sd = 20)))


#Simulate for instructor with mean 90 and large standard deviation
grade2 <- data.frame(c(rnorm(50, mean = 90, 10)))


colnames(grade2) <- colnames(grade1) 
#create a data frame with the simulated data
all.grades <- data.frame(rbind(grade1, grade2))


#create instructor variable
instructor = c(rep("A", 50), rep("B", 50))

data.full <- cbind(all.grades, instructor)
data.full<- data.full %>% rename(grade = c.rnorm.50..mean...80..sd...20..)

gf_histogram(data = data.full, ~grade, aes(color= instructor))

